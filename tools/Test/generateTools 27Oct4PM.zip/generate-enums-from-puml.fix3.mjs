#!/usr/bin/env node
// generate-enums-from-puml.mjs (v1.2-fix3)
// Enum-only generator: emits enum JSON from PUML SCHEMAHINTS.
// Supports v1.2 keys: enumId, targetPath, sourcePath (+ legacy path).
// Supports both inline [a,b] and block-style lists:
//   enum:
//     - A
//     - B

import fs from 'fs';
import path from 'path';
import process from 'process';

// -------- argv helpers --------
const argv = process.argv.slice(2);
function getArgVal(name, def = undefined) {
  // Supports: --name=value  OR  --name value  OR  (boolean presence ⇒ true)
  const i = argv.findIndex(a => a === name || a.startsWith(name + "="));
  if (i === -1) return def;
  const eq = argv[i].indexOf("=");
  if (eq > -1) return argv[i].slice(eq+1);
  // no "=", check next as value if present and not another flag
  if (i + 1 < argv.length && !argv[i+1].startsWith("--")) return argv[i+1];
  return true;
}

let baseId = String(getArgVal("--baseId", "")).trim();
if (!baseId) {
  console.error("ERROR: --baseId is required (e.g., --baseId https://schemas.example.org/hatpro/)");
  process.exit(1);
}
if (!/\/$/.test(baseId)) baseId += "/";
const packagesDir = String(getArgVal("--packagesDir", "packages")).trim();

// -------- file utils --------
function listPumlFiles(root) {
  const out = [];
  function walk(dir) {
    let entries;
    try { entries = fs.readdirSync(dir, { withFileTypes: true }); }
    catch { return; }
    for (const e of entries) {
      const p = path.join(dir, e.name);
      if (e.isDirectory()) walk(p);
      else if (e.isFile() && e.name.toLowerCase().endsWith(".puml")) out.push(p);
    }
  }
  walk(root);
  return out;
}

function ensureDir(p) {
  fs.mkdirSync(path.dirname(p), { recursive: true });
}

// -------- SCHEMAHINTS parsing --------
function parseHintsFromText(text) {
  const notes = [];
  const noteRe = /note\s+(?:right|left|over)\s+of[\s\S]*?end note/gi;
  let m;
  while ((m = noteRe.exec(text)) !== null) {
    const block = m[0];
    if (!/^\s*SCHEMAHINTS\b/m.test(block)) continue;
    notes.push(parseSchemaHints(block));
  }
  return notes.flat();
}

function parseSchemaHints(block) {
  const lines = block.replace(/\t/g, "  ").split(/\r?\n/);
  const results = [];
  let inHints = false;
  let current = { fields: {} };
  let currentField = null;

  function commitIfAny() {
    if (Object.keys(current.fields).length) {
      results.push(JSON.parse(JSON.stringify(current)));
    }
  }

  for (let idx = 0; idx < lines.length; idx++) {
    let raw = lines[idx];
    // strip PlantUML comment lines that start with a single quote
    if (/^\s*'/.test(raw)) continue;
    const line = raw;
    if (!inHints) {
      if (/^\s*SCHEMAHINTS\b/.test(line)) inHints = true;
      continue;
    }
    if (/^\s*end note\b/i.test(line)) break;

    // field start
    const f = line.match(/^\s*field\s+([A-Za-z_][A-Za-z0-9_]*)\s*:\s*$/);
    if (f) { currentField = f[1]; current.fields[currentField] = {}; continue; }

    // key: value (or start of enumDefine block)
    const kv = line.match(/^\s*([A-Za-z][A-Za-z0-9_-]*)\s*:\s*(.*)\s*$/);
    if (kv && currentField) {
      let [, key, val] = kv;
      val = val.trim();

      // nested enumDefine block
      if (key === "enumDefine" && val === "") {
        const obj = {};
        idx = readNestedObject(lines, idx + 1, obj);
        current.fields[currentField].enumDefine = obj;
        continue;
      }

      // block lists for enum-ish keys
      if ((key === "enum" || key === "x-enumNames" || key === "x-enumDescriptions") && val === "") {
        const arr = [];
        idx = readBlockList(lines, idx + 1, arr);
        current.fields[currentField][key] = arr;
        continue;
      }

      // inline array [a, b]
      if (/^\[.*\]$/.test(val)) {
        current.fields[currentField][key] = val.slice(1,-1).split(",").map(s => s.trim()).filter(Boolean);
        continue;
      }

      // scalars
      current.fields[currentField][key] = coerceScalar(val);
      continue;
    }
  }
  commitIfAny();
  return results;
}

function readNestedObject(lines, startIdx, outObj) {
  // read further-indented lines until dedent or end
  let idx = startIdx - 1;
  for (let j = startIdx; j < lines.length; j++) {
    const raw = lines[j];
    if (/^\s*'/.test(raw)) { idx = j; continue; } // skip comments
    if (/^\s*end note\b/i.test(raw)) { idx = j - 1; break; }
    if (/^\s*field\s+[A-Za-z_]/.test(raw)) { idx = j - 1; break; }
    if (!/^\s{2,}\S/.test(raw)) { idx = j - 1; break; } // dedent => stop
    const ln = raw.replace(/\t/g, "  ");
    const kv2 = ln.match(/^\s*([A-Za-z][A-Za-z0-9_-]*)\s*:\s*(.*)\s*$/);
    if (!kv2) { idx = j; continue; }
    let [, k2, v2] = kv2;
    v2 = v2.trim();
    if ((k2 === "enum" || k2 === "x-enumNames" || k2 === "x-enumDescriptions") && v2 === "") {
      const arr = [];
      const stop = readBlockList(lines, j + 1, arr);
      outObj[k2] = arr;
      j = stop;
      idx = j;
      continue;
    }
    if (/^\[.*\]$/.test(v2)) {
      outObj[k2] = v2.slice(1,-1).split(",").map(s => s.trim()).filter(Boolean);
    } else if (/^(true|false)$/i.test(v2)) {
      outObj[k2] = /^true$/i.test(v2);
    } else if (/^-?\d+(?:\.\d+)?$/.test(v2)) {
      outObj[k2] = Number(v2);
    } else {
      outObj[k2] = v2;
    }
    idx = j;
  }
  return idx;
}

function readBlockList(lines, startIdx, outArr) {
  // Read lines like: "    - Value", until dedent or end
  let j = startIdx;
  for (; j < lines.length; j++) {
    const raw = lines[j];
    if (/^\s*'/.test(raw)) continue;
    if (/^\s*end note\b/i.test(raw)) return j - 1;
    if (!/^\s{2,}\S/.test(raw)) return j - 1;
    const m = raw.match(/^\s*-[ \t]+(.+)$/);
    if (!m) return j - 1;
    outArr.push(m[1].trim());
  }
  return j - 1;
}

function coerceScalar(v) {
  if (/^(true|false)$/i.test(v)) return /^true$/i.test(v);
  if (/^-?\d+(?:\.\d+)?$/.test(v)) return Number(v);
  return v;
}

// -------- enum emission --------
function deriveEnumFileFromEnumId(enumId) {
  // classic: /seg/subs/Name -> packages/seg/json/enums/subs/Name.json
  const parts = enumId.replace(/^\//, "").split("/").filter(Boolean);
  const seg = parts[0];
  const name = parts[parts.length - 1];
  const subs = parts.slice(1, -1);
  const rel = path.join(seg, "json", "enums", ...subs, name + ".json");
  return path.join(packagesDir, rel);
}

function emitEnumFromDefine(ed) {
  const enumId = (ed.enumId || ed.path || "").trim();
  if (!enumId || !enumId.startsWith("/")) {
    console.warn(`! Skipping enum with invalid enumId/path: "${enumId}"`);
    return;
  }
  const targetPath = ed.targetPath ? String(ed.targetPath).trim() : "";
  const $id = baseId + enumId.replace(/^\//, "") + ".json";
  const outFile = targetPath
    ? path.join(packagesDir, targetPath.replace(/^\//, "")) + ".json"
    : deriveEnumFileFromEnumId(enumId);

  const node = {
    $id,
    title: ed.title || enumId.split("/").pop(),
    type: (ed.type === "integer" ? "integer" : "string"),
    enum: Array.isArray(ed.enum) ? ed.enum.slice() : []
  };
  if (Array.isArray(ed["x-enumNames"])) node["x-enumNames"] = ed["x-enumNames"].slice();
  if (Array.isArray(ed["x-enumDescriptions"])) node["x-enumDescriptions"] = ed["x-enumDescriptions"].slice();
  if (ed.sourcePath) node["x-sourcePath"] = String(ed.sourcePath);

  const shouldGenerate = (typeof ed.generate === "boolean") ? ed.generate : true;
  if (!shouldGenerate) {
    console.log(`↷ Skipped (generate:false) ${outFile}`);
    return;
  }

  ensureDir(outFile);
  fs.writeFileSync(outFile, JSON.stringify(node, null, 2), "utf-8");
  console.log(`✓ Wrote enum ${outFile}`);
}

function processFile(filePath) {
  const text = fs.readFileSync(filePath, "utf-8");
  const notes = parseHintsFromText(text);
  notes.forEach(note => {
    for (const [fname, spec] of Object.entries(note.fields || {})) {
      if (spec && typeof spec === "object" && spec.enumDefine && typeof spec.enumDefine === "object") {
        emitEnumFromDefine(spec.enumDefine);
      }
    }
  });
}

function main() {
  const root = path.resolve(process.cwd(), packagesDir);
  const files = listPumlFiles(root);
  if (!files.length) {
    console.warn(`No .puml files found under ${root}`);
    return;
  }
  files.forEach(processFile);
}

main();
